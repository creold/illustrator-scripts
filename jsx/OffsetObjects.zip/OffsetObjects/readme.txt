Important:
The script comes with a supplementary file named OffsetObjects_Style.ai, containing a graphic style for the contours.
Place this file in the same folder as the JSX script; otherwise, the script will not run.

***

Важно:
В комплекте со скриптом находится вспомогательный файл OffsetObjects_Style.ai c графическим стилем для контуров.
Поместите его в одну папку со скриптом, иначе скрипт не запустится.