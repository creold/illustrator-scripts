/*
  OffsetObjects.jsx for Adobe Illustrator
  Description: Offsets objects like the native Offset Path command, 
  but works on paths, symbols, rasters and offers additional options
  Date: July, 2025
  Author: Sergey Osokin, email: hi@sergosokin.ru

  Installation: https://github.com/creold/illustrator-scripts#how-to-run-scripts
  ********************************************************************************************
  * NOTE: Download "offsetObjects_style.ai". And put the file in the folder with this script *
  ********************************************************************************************

  Release notes:
  0.1.1 Added Joins and Miter limit options from the Offfset Path dialog
  0.1 Initial version

  Donate (optional):
  If you find this script helpful, you can buy me a coffee
  - via Buymeacoffee: https://www.buymeacoffee.com/aiscripts
  - via Donatty https://donatty.com/sergosokin
  - via DonatePay https://new.donatepay.ru/en/@osokin
  - via YooMoney https://yoomoney.ru/to/410011149615582

  NOTICE:
  Tested with Adobe Illustrator CC 2019-2025 (Mac/Win).
  This script is provided "as is" without warranty of any kind.
  Free to use, not for sale

  Released under the MIT license
  http://opensource.org/licenses/mit-license.php

  Check my other scripts: https://github.com/creold
*/

//@target illustrator
app.preferences.setBooleanPreference('ShowExternalJSXWarning', false); // Fix drag and drop a .jsx file

// Main function
function main() {
  var SCRIPT = {
        name: 'Offset Objects',
        version: 'v0.1.1'
      };

  var CFG = {
    isUseSwatch: false, // true - apply spot swatch, false - apply solid color
    swatchName: 'Cut', // Default spot swatch
    swatchValue: [0, 100, 0, 0], // Default CMYK values
    layerName: 'Contour', // Layen name for "Move to New Layer" option
    minArea: 1, // Remove resulting smallest paths. Units: px
    graphStyleFile: 'OffsetObjects_Style.ai',
    graphStyleName: 'Offset_AIS',
    aiVers: parseFloat(app.version),
    isMac: /mac/i.test($.os),
  }

  var SETTINGS = {
    name: SCRIPT.name.replace(/\s/g, '_') + '_data.json',
    folder: Folder.myDocuments + '/Adobe Scripts/'
  };

  if (!isCorrectEnv('version:16', 'selection:1')) return;

  var doc = app.activeDocument;
  var sel = app.selection;
  var scriptPath = File($.fileName).parent;
  var tplFile = new File(scriptPath.fsName + '/' + CFG.graphStyleFile);

  if (!tplFile.exists) {
    alert('The ' + CFG.graphStyleFile + ' file for the script was not found\nDownload: <url>\n\nAnd put the file in the folder with this script', 'Script Warning');
    return;
  }

  // DIALOG
  var win = new Window('dialog', SCRIPT.name + ' ' + SCRIPT.version);
      win.orientation = 'column';
      win.alignChildren = ['fill', 'top'];
      win.spacing = 10;
      win.opacity = 0.97;

  // WRAPPER
  var wrapper = win.add('group');
      wrapper.orientation = 'row';
      wrapper.alignChildren = ['left', 'center'];

  // LABELS
  var labelsGrp = wrapper.add('group');
      labelsGrp.orientation = 'column';
      labelsGrp.alignChildren = ['left', 'top'];
      labelsGrp.spacing = 18;

  labelsGrp.add('statictext', undefined, 'Offset:');
  labelsGrp.add('statictext', undefined, 'Joins:');
  labelsGrp.add('statictext', undefined, 'Miter Limit:');
  labelsGrp.add('statictext', undefined, 'Stroke:');

  // INPUTS
  var inputsGrp = wrapper.add('group');
      inputsGrp.orientation = 'column';
      inputsGrp.alignChildren = ['left', 'top'];
      inputsGrp.spacing = 10;

  // OFFSET
  var offsetGrp = inputsGrp.add('group');
      offsetGrp.alignChildren = ['left', 'center'];

  var offsetInp = offsetGrp.add('edittext', undefined, 0);
      offsetInp.preferredSize.width = 50;

  // Focus input field on compatible versions
  if (CFG.isMac || CFG.aiVers >= 26.4 || CFG.aiVers <= 17) {
    offsetInp.active = true;
  }

  var offsetUnits = offsetGrp.add('dropdownlist', undefined, ['pt', 'pc', 'in', 'mm', 'cm', 'px']);
      offsetUnits.preferredSize.width = 48;
      offsetUnits.selection = 0;

  // JOINS
  var joinGrp = inputsGrp.add('group');
      joinGrp.alignChildren = ['left', 'center'];

  var joinList = joinGrp.add('dropdownlist', undefined, ['Miter', 'Round', 'Bevel']);
      joinList.preferredSize.width = 110;
      joinList.selection = 0;

  // STROKE WEIGHT
  var miterGrp = inputsGrp.add('group');
      miterGrp.alignChildren = ['left', 'center'];

  var miterInp = miterGrp.add('edittext', undefined, 4);
      miterInp.preferredSize.width = 110;

  // STROKE WEIGHT
  var strokeGrp = inputsGrp.add('group');
      strokeGrp.alignChildren = ['left', 'center'];

  var strokeInp = strokeGrp.add('edittext', undefined, 0.25);
      strokeInp.preferredSize.width = 50;

  var strokeUnits = strokeGrp.add('dropdownlist', undefined, ['pt', 'pc', 'in', 'mm', 'cm', 'px']);
      strokeUnits.preferredSize.width = 48;
      strokeUnits.selection = 0;

  // CONTOUR HIERARCHY
  var posPnl = win.add('panel', undefined, 'Position');
      posPnl.orientation = 'column';
      posPnl.alignChildren = ['fill', 'top'];
      posPnl.margins = [10, 15, 10, 7];

  var isUnder = posPnl.add('radiobutton', undefined, 'Under Object');
      isUnder.value = true;
  var isAbove = posPnl.add('radiobutton', undefined, 'Above Object');

  var cntnrPnl = win.add('panel', undefined, 'Container');
      cntnrPnl.orientation = 'column';
      cntnrPnl.alignChildren = ['fill', 'top'];
      cntnrPnl.margins = [10, 15, 10, 7];

  var isSameLayer = cntnrPnl.add('radiobutton', undefined, 'Keep in Same Layer');
      isSameLayer.value = true;
  var isNewLayer = cntnrPnl.add('radiobutton', undefined, 'Move to New Layer');
  var isGroup = cntnrPnl.add('radiobutton', undefined, 'Group with Object');

  // BUTTONS
  var btns = win.add('group');
      btns.orientation = 'row';
      btns.alignChildren = ['fill', 'fill'];

  // Platform-specific button order
  var cancel, ok;
  if (CFG.isMac) {
    cancel = btns.add('button', undefined, 'Cancel', { name: 'cancel' });
    ok = btns.add('button', undefined, 'OK', { name: 'ok' });
  } else {
    ok = btns.add('button', undefined, 'OK', { name: 'ok' });
    cancel = btns.add('button', undefined, 'Cancel', { name: 'cancel' });
  }

  cancel.helpTip = 'Press Esc to Close';
  ok.helpTip = 'Press Enter to Run';

  var copyright = win.add('statictext', undefined, '\u00A9 Sergey Osokin. Visit Github');
  copyright.justify = 'center';

  // EVENTS
  loadSettings(SETTINGS);

  // Use Up / Down arrow keys (+ Shift) to change value
  bindStepperKeys(offsetInp, -5000, 5000);
  bindStepperKeys(miterInp, -16000, -16000);
  bindStepperKeys(strokeInp, 0, 1000);

  joinList.onChange = offsetUnits.onChange = strokeUnits.onChange = function() {
    offsetInp.active = false;
    strokeInp.active = false;
  }

  cancel.onClick = win.close;
  ok.onClick = okClick;

  copyright.addEventListener('mousedown', function () {
    openURL('https://github.com/creold');
  });

  /**
   * Handle the click event for the OK button.
   * Save settings, import style, and process selected items
   */
  function okClick() {
    saveSettings(SETTINGS);
    importStyle(tplFile, CFG.graphStyleName);

    var options = {
      isUnder: isUnder.value,
      isNewLayer: isNewLayer.value,
      isGroup: isGroup.value,
      offsetStyle: {},
      offsetValue: convertToPt( strToNum(offsetInp.text), offsetUnits),
      miterValue: strToNum(miterInp.text, 4),
      joinType: joinList.selection.index === 0 ? 2 : (joinList.selection.index === 1 ? 0 : 1),
      strokeValue: convertToPt( Math.abs(strToNum(strokeInp.text)), strokeUnits),
      minArea: CFG.minArea,
      layerName: CFG.layerName,
    }

    try { 
      options.offsetStyle = doc.graphicStyles.getByName(CFG.graphStyleName)
    } catch (err) { return; }

    deselect();

    // Prepare a new layer for the contours
    if (options.isNewLayer) {
      var targetLayer;
      try {
        targetLayer = doc.layers[options.layerName];
      } catch (err) {
        targetLayer = doc.layers.add();
        targetLayer.name = options.layerName;
      }
      // Set up the layer properties
      targetLayer.visible = true;
      targetLayer.locked = false;
      targetLayer.zOrder(options.isUnder ? ZOrderMethod.SENDTOBACK : ZOrderMethod.BRINGTOFRONT);
    }

    // Prepare the color for filling the contours
    var targetColor;
    if (CFG.isUseSwatch) {
      getSpotSwatch(CFG.swatchName, CFG.swatchValue);
      targetColor = doc.swatches[CFG.swatchName].color;
    } else {
      targetColor = setCMYKColor(CFG.swatchValue);
    }

    // Process selected items
    var results = []
    for (var i = 0, len = sel.length; i < len; i++) {
      var paths = process(doc, sel[i], options, targetColor);
      results = results.concat(paths);
    }

    // Select all contours
    app.selection = results;

    offsetStyle.remove();
    win.close();
  }

  win.onClose = function () {
    try {
      doc.graphicStyles.getByName(CFG.graphStyleName).remove();
    } catch (err) {}
  }

  /**
   * Handle keyboard input to shift numerical values
   * @param {Object} input - The input element to which the event listener will be attached
   * @param {number} min - The minimum allowed value for the numerical input
   * @param {number} max - The maximum allowed value for the numerical input
   * @returns {void}
   */
  function bindStepperKeys(input, min, max) {
    input.addEventListener('keydown', function (kd) {
      var step = ScriptUI.environment.keyboardState['shiftKey'] ? 10 : 1;
      var num = parseFloat(this.text);
      if (kd.keyName == 'Down' || kd.keyName == 'LeftBracket') {
        this.text = (typeof min !== 'undefined' && (num - step) < min) ? min : num - step;
        kd.preventDefault();
      }
      if (kd.keyName == 'Up' || kd.keyName == 'RightBracket') {
        this.text = (typeof max !== 'undefined' && (num + step) > max) ? max : num + step;
        kd.preventDefault();
      }
    });
  }

  /**
   * Save UI options to a file
   * @param {object} prefs - Object containing preferences
   * @returns {void}
   */
  function saveSettings(prefs) {
    if (!Folder(prefs.folder).exists) {
      Folder(prefs.folder).create();
    }

    var f = new File(prefs.folder + prefs.name);
    f.encoding = 'UTF-8';
    f.open('w');

    var data = {};
    data.win_x = win.location.x;
    data.win_y = win.location.y;

    data.offset = offsetInp.text;
    data.offsetUnits = offsetUnits.selection.index;

    data.joins = joinList.selection.index;
    data.miter = miterInp.text;

    data.stroke = strokeInp.text;
    data.strokeUnits = strokeUnits.selection.index;

    data.position = isUnder.value ? 0 : 1;
    data.container = isSameLayer.value ? 0 : (isNewLayer.value ? 1 : 2);

    f.write( stringify(data) );
    f.close();
  }

  /**
   * Load options from a file
   * @param {object} prefs - Object containing preferences
   * @returns {void}
   */
  function loadSettings(prefs) {
    var f = File(prefs.folder + prefs.name);
    if (!f.exists) return;

    try {
      f.encoding = 'UTF-8';
      f.open('r');
      var json = f.readln();
      try { var data = new Function('return (' + json + ')')(); }
      catch (err) { return; }
      f.close();

      if (typeof data != 'undefined') {
        win.location = [
          data.win_x ? parseInt(data.win_x) : 100,
          data.win_y ? parseInt(data.win_y) : 100
        ];

        offsetInp.text = data.offset || 0;
        offsetUnits.selection = parseInt(data.offsetUnits) || 0;

        joinList.selection = parseInt(data.joins) || 0;
        miterInp.text = data.miter || 4;

        strokeInp.text = data.stroke || 0;
        strokeUnits.selection = parseInt(data.strokeUnits) || 0;

        posPnl.children[parseInt(data.position) || 0].value = true;
        cntnrPnl.children[parseInt(data.container) || 0].value = true;
      }
    } catch (err) { return; }
  }

  win.show();
}

/**
 * Check if the environment is correct for running the script
 * @param {...string} args - Variable number of arguments to check
 * @returns {boolean} - Return true if the environment is correct, false otherwise
 */
function isCorrectEnv() {
  var args = ['app', 'document'];
  args.push.apply(args, arguments);

  for (var i = 0; i < args.length; i++) {
    var arg = args[i].toString().toLowerCase();
    switch (true) {
      case /app/g.test(arg):
        if (!/illustrator/i.test(app.name)) {
          alert('Wrong application\nRun script from Adobe Illustrator', 'Script error');
          return false;
        }
        break;
      case /version/g.test(arg):
        var rqdVers = parseFloat(arg.split(':')[1]);
        if (parseFloat(app.version) < rqdVers) {
          alert('Wrong app version\nSorry, script only works in Illustrator v.' + rqdVers + ' and later', 'Script error');
          return false;
        }
        break;
      case /document/g.test(arg):
        if (!app.documents.length) {
          alert('No documents\nOpen a document and try again', 'Script error');
          return false;
        }
        break;
      case /selection/g.test(arg):
        var rqdLen = parseFloat(arg.split(':')[1]);
        if (app.selection.length < rqdLen || selection.typename === 'TextRange') {
          alert('Few objects are selected\nPlease select at least ' + rqdLen + ' object and try again', 'Script error');
          return false;
        }
        break;
    }
  }

  return true;
}

/**
 * Import a graphic style from a specified file to the active document
 * @param {File} file - The file from which to import the style
 * @param {string} styleName - The name of the style to import
 */
function importStyle(file, styleName) {
  var activeDoc = app.activeDocument;
  var tplDoc = app.open(file);

  var item;
  // Create a default rectangle item in the template document
  if (!tplDoc.pathItems.length) {
    item = tplDoc.layers[0].pathItems.rectangle(0, 0, 10, 10);
    item.filled = true;
    item.stroked = false;
  } else { 
    // Prepare an existing item in the template document
    item = tplDoc.pathItems[0];
    tplDoc.layers[0].locked = false;
    tplDoc.layers[0].visible = true;
    item.locked = false;
    item.hidden = false;
  }

  // Apply a graphic style
  try {
    var targetStyle = tplDoc.graphicStyles.getByName(styleName);
    targetStyle.applyTo(item);
  } catch (err) {
    alert('The ' + styleName + ' style was not found\nYou may have changed the template.\n\nDownload: <url>\n\nAnd put the file in the folder with this script', 'Script Warning');
    tplDoc.close(SaveOptions.DONOTSAVECHANGES);
    return;
  }

  // Duplicate an item to the active document for import a graphic style
  var dup = item.duplicate(activeDoc.selection[0].layer, ElementPlacement.PLACEATEND);
  dup.position = [-4000, -4000]
  dup.remove();

  activeDoc.activate();
  tplDoc.close(SaveOptions.DONOTSAVECHANGES);
}

/**
 * Convert string to number
 * @param {string} str - The string to convert to a number
 * @param {number} def - The default value to return if the conversion fails
 * @returns {number} The converted number
 */
function strToNum(str, def) {
  if (arguments.length == 1 || def == undefined) def = 0;
  str = str.replace(/,/g, '.').replace(/[^\d.-]/g, '');
  str = str.split('.');
  str = str[0] ? str[0] + '.' + str.slice(1).join('') : '';
  str = str.substr(0, 1) + str.substr(1).replace(/-/g, '');
  if (isNaN(str) || !str.length) return parseFloat(def);
  else return parseFloat(str);
}

/**
 * Recalculate the value in the selected units
 * @param {number} value - The input value to be converted
 * @param {Dropdown} dropdown - The dropdown list containing unit names
 * @returns {number} The recalculated value in points
 */
function convertToPt(value, dropdown) {
  return convertUnits(value, dropdown.selection.text.slice(0, 2), 'px');
}

/**
 * Convert units of measurement from one unit to another
 * @param {number|string} value - The numeric data to be converted
 * @param {string} currUnits - The current units of the value (e.g., 'px', 'mm')
 * @param {string} newUnits - The target units for conversion (e.g., 'pt', 'in')
 * @returns {number} The converted value in the new units
 */
function convertUnits(value, currUnits, newUnits) {
  return UnitValue(value, currUnits).as(newUnits);
}

/**
 * Retrieve an existing swatch or creates a new one
 * @param {string} name - The name of the spot color to add
 * @param {Array} value - The CMYK color values to use for the spot color
 * @returns {Object} The newly created spot color object
 */
function getSpotSwatch(name, value) {
  var doc = app.activeDocument;
  var color = setCMYKColor(value);
  var swatch = null;

  try {
    swatch = doc.spots.getByName(name);
  } catch (err) {
    swatch = doc.spots.add();
    swatch.name = name;
    swatch.colorType = ColorModel.SPOT;
    swatch.color = color;
  }

  var spotColor = new SpotColor();
  spotColor.spot = color;
  spotColor.tint = 100;
}

/**
 * Create a CMYK object with validated CMYK values
 * @param {Array} cmyk - An array of four numbers representing CMYK values
 * @returns {Object} A CMYK color with validated and clamped CMYK values
 */
function setCMYKColor(cmyk) {
  var defaultCMYK = [0, 0, 0, 100];

  // Validate and clamp each CMYK value
  for (var i = 0; i < 4; i++) {
    if (cmyk[i] !== undefined && typeof cmyk[i] === 'number') {
      defaultCMYK[i] = Math.max(0, Math.min(100, cmyk[i]));
    }
  }

  // Create and return a new CMYKColor object
  var color = new CMYKColor();
  color.cyan = defaultCMYK[0];
  color.magenta = defaultCMYK[1];
  color.yellow = defaultCMYK[2];
  color.black = defaultCMYK[3];

  return color;
}

/**
 * Process an Illustrator document item by offsetting, styling, and repositioning it
 * @param {Object} doc - The working Illustrator document
 * @param {Object} origItem - The original item to process
 * @param {Object} options - Configuration options for processing
 * @param {Object} targetColor - The target color to apply to the processed item
 * @returns {Object} The processed item
 */
function process(doc, origItem, options, targetColor) {
  var offsetItem = offsetObject(origItem, options);
  
  // Extracts paths from the processed item
  var paths = [];
  if (/group/i.test(offsetItem.typename)) {
    paths = getPaths(offsetItem.pageItems);
  } else if (/compound/i.test(offsetItem.typename)) {
    paths = offsetItem.pathItems;
  } else {
    paths = [offsetItem];
  }

  stylePaths(paths, targetColor, options.strokeValue);

  // Unite and simplify group paths
  if (/group/i.test(offsetItem.typename)) {
    offsetItem = mergeGroup(offsetItem, options.minArea);
  }

  // Change z-order
  offsetItem.move(origItem, options.isUnder ? ElementPlacement.PLACEAFTER : ElementPlacement.PLACEBEFORE);

  // Group original and offset items
  if (options.isGroup) {
    var comboGroup = origItem.layer.groupItems.add();
    comboGroup.name = origItem.name;
    comboGroup.move(origItem, ElementPlacement.PLACEBEFORE);
    origItem.move(comboGroup, ElementPlacement.PLACEATBEGINNING);
    offsetItem.move(comboGroup, options.isUnder ? ElementPlacement.PLACEATEND : ElementPlacement.PLACEATBEGINNING);
  } else if (options.isNewLayer) {
    // Move paths to a new layer
    var targetLayer = doc.layers[options.layerName];
    offsetItem.move(targetLayer, ElementPlacement.PLACEATBEGINNING);
  }

  // Remove unnecessaty group
  if (/group/i.test(offsetItem.typename) && offsetItem.pageItems.length === 1) {
    app.executeMenuCommand('ungroup');
  }

  offsetItem = app.selection[0];
  deselect();

  return offsetItem;
}

/**
 * Offset an object in Adobe Illustrator by duplicating it and applying an offset path effect
 * @param {Object} item - The item to be offset
 * @param {Object} options - Configuration options for processing
 * @returns {Object} The newly created offset object
 */
function offsetObject(item, options) {
  // Duplicate the item and place it right after the original
  var dup = item.duplicate();
  dup.move(item, ElementPlacement.PLACEAFTER);
  dup.selected = true;

  processClippingMask(dup);

  // Outline Stroke
  app.executeMenuCommand('OffsetPath v22');
  dup = app.selection[0];

  /* Live Effects
    1. Drop Shadow
    2. Outline Object
    4. Outline Stroke
    3. Pathfinder > Merge
    4. Pathfinder > Divide
    5. Pathfinder > Add
    6. Offset Path
  */

  // Apply the specified style to the duplicated item
  if (options.offsetStyle !== undefined) {
    options.offsetStyle.applyTo(dup);
  }

  // Define and apply the offset path effect
  var xmlOffsetPath = '<LiveEffect name="Adobe Offset Path"><Dict data="R ofst #1 I jntp #2 R mlim #3 "/></LiveEffect>';
  xmlOffsetPath = xmlOffsetPath.replace(/#1/, options.offsetValue).replace(/#2/, options.joinType).replace(/#3/, options.miterValue);
  dup.applyEffect(xmlOffsetPath);

  updateScreen();

  // Expand the style to finalize the offset effect
  app.executeMenuCommand('expandStyle');

  // Return the newly created offset object
  return app.selection[0];
}

/**
 * Process a clipping mask for a given item
 * A mask are getting ready for correct offset
 * @param {Object} item - The item to process
 */
function processClippingMask(item) {
  if (!/group/i.test(item.typename)) return;

  if (item.clipped) {
    var mask = getClippingMask(item);
    if (mask !== null && mask.hasOwnProperty('filled') && mask.filled) {
      mask.duplicate(item, ElementPlacement.PLACEATEND);
      mask.clipping = false;
    }
  }

  for (var i = 0, len = item.pageItems.length; i < len; i++) {
    processClippingMask(item.pageItems[i]);
  }
}

/**
 * Get the clipping mask from a group
 * @param {Object} group - The group of items to search for a clipping mask
 * @returns {Object} The clipping path item if found, otherwise null
 */
function getClippingMask(group) {
  for (var i = 0, len = group.pageItems.length; i < len; i++) {
    var item = group.pageItems[i];
    if (/compound/i.test(item.typename) && item.pathItems.length) {
      item = item.pathItems[0];
    }
    if (item.hasOwnProperty('clipping') && item.clipping) {
      return item;
    }
  }
  return null;
}

/**
 * Clear the current selection in the Illustrator
 */
function deselect() {
  app.selection = null;
  app.executeMenuCommand('deselectall');
}

/**
 * Force the screen to update by toggling artboard edges
 * @returns {void}
 */
function updateScreen() {
  if (parseFloat(app.version) >= 16) {
    app.executeMenuCommand('artboard');
    app.executeMenuCommand('artboard');
  } else {
    app.redraw();
  }
}

/**
 * Recursively collect path items from a given collection
 * @param {(Object|Array)} coll - The collection of items to search through
 * @returns {Array} An array of path items found in the collection
 */
function getPaths(coll) {
  var results = [];

  for (var i = 0; i < coll.length; i++) {
    var item = coll[i];
    if (item.pageItems && item.pageItems.length) {
      results = results.concat( getPaths(item.pageItems) );
    } else if (/compound/i.test(item.typename) && item.pathItems.length) {
      results = results.concat( getPaths(item.pathItems) );
    } else if (/pathitem/i.test(item.typename)) {
      results.push(item);
    }
  }

  return results;
}

/**
 * Apply colors and strokes to an array of paths
 * @param {Array} paths - The array of paths to style
 * @param {Object} targetColor - The target color to apply
 * @param {number} strokeValue - The stroke width to apply
 */
function stylePaths(paths, targetColor, strokeValue) {
  for (var i = 0, len = paths.length; i < len; i++) {
    var path = paths[i];
    if (path.hasOwnProperty('fillColor')) {
      path.filled = true;
      path.fillColor = targetColor;
    }
    path.blendingMode = BlendModes.NORMAL;
    path.opacity = 100;
    path.stroked = !!strokeValue;
    if (strokeValue) {
      path.strokeWidth = strokeValue;
      path.strokeColor = targetColor;
    }
  }
}

/**
 * Combining overlapping paths in a group
 * @param {GroupItem} group - The group item to process
 * @param {number} minArea - The minimum area threshold for paths
 * @returns {PageItem} The processed item
 */
function mergeGroup(group, minArea) {
  app.executeMenuCommand('Live Pathfinder Add');
  updateScreen();
  app.executeMenuCommand('expandStyle');

  var mergedItem = app.selection[0];

  if (/group/i.test(mergedItem.typename)) {
    // Remove unnecessaty group
    if (mergedItem.pageItems.length === 1) {
      app.executeMenuCommand('ungroup');
    } else {
      // Remove smallest paths
      var paths = getPaths(mergedItem.pageItems);
      for (var j = paths.length - 1; j >= 0; j--) {
        var path = paths[j];
        if (path.hasOwnProperty('area') && Math.abs(path.area) < minArea) {
          path.remove();
        }
      }
    }
  }

  return app.selection[0];
}

/**
 * Open a URL in the default web browser
 * @param {string} url - The URL to open in the web browser
 * @returns {void}
*/
function openURL(url) {
  var html = new File(Folder.temp.absoluteURI + '/aisLink.html');
  html.open('w');
  var htmlBody = '<html><head><META HTTP-EQUIV=Refresh CONTENT="0; URL=' + url + '"></head><body> <p></body></html>';
  html.write(htmlBody);
  html.close();
  html.execute();
}

/**
 * Serialize a JavaScript plain object into a JSON-like string
 * @param {Object} obj - The object to serialize
 * @returns {string} A JSON-like string representation of the object
 */
function stringify(obj) {
  var json = [];
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      var value = obj[key].toString();
      value = value
        .replace(/\t/g, "\t")
        .replace(/\r/g, "\r")
        .replace(/\n/g, "\n")
        .replace(/"/g, '\"');
      json.push('"' + key + '":"' + value + '"');
    }
  }
  return "{" + json.join(",") + "}";
}

// Run script
try {
  main();
} catch (err) {}